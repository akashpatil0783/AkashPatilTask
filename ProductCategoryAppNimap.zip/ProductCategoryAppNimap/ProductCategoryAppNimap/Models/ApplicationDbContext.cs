﻿//using Microsoft.EntityFrameworkCore;
//namespace ProductCategoryAppNimap.Models
//{
//    public class ApplicationDbContext : DbContext
//    {
//        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
//           : base(options)
//        {
//        }

//        public DbSet<Category> Categories { get; set; }
//        public DbSet<Product> Products { get; set; }
//    }
//}
using Microsoft.EntityFrameworkCore;
namespace ProductCategoryAppNimap.Models
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
           : base(options)
        {
        }

        public DbSet<Category> Categories { get; set; }
        public DbSet<Product> Products { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Product>()
                .HasOne(p => p.Category)
                .WithMany(c => c.Products)
                .HasForeignKey(p => p.CategoryId)
                .OnDelete(DeleteBehavior.Cascade);

            base.OnModelCreating(modelBuilder);
        }
    }
}
