﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using ProductCategoryAppNimap.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProductCategoryAppNimap.Controllers
{
    public class ProductController : Controller
    {
        private readonly ApplicationDbContext _context;

        public ProductController(ApplicationDbContext context)
        {
            _context = context;
        }

        // ✅ FIX: Pass a list of products to the view
        //public IActionResult Index()
        //{
        //    var products = _context.Products.ToList();  // Fetch products from database
        //    return View(products);  // Pass the product list to the view
        //}
        public IActionResult Index()
        {
            var products = _context.Products
                .Join(_context.Categories,
                      p => p.CategoryId,
                      c => c.CategoryId,
                      (p, c) => new Product // ✅ Correct instantiation
                      {
                          ProductId = p.ProductId,
                          ProductName = p.ProductName,
                          CategoryId = p.CategoryId,
                          CategoryName = c.CategoryName // ✅ Correctly assigns CategoryName
                      })
                .ToList();

            return View(products);
        }


        [HttpGet]
        public IActionResult Create()
        {
            ViewBag.CategoryList = new SelectList(_context.Categories, "CategoryId", "CategoryName");
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken] // Optional, but recommended for security
        public async Task<IActionResult> Create(Product product)
        {
            //if (!ModelState.IsValid)
            //{
            //    foreach (var error in ModelState.Values.SelectMany(v => v.Errors))
            //    {
            //        Console.WriteLine("Validation Error: " + error.ErrorMessage);
            //    }
            //}

                // Debugging Log
              //  Console.WriteLine($"Product Name: {product.ProductName}, Category ID: {product.CategoryId}");

            // Ensure category exists before inserting product
            var categoryExists = _context.Categories.Any(c => c.CategoryId == product.CategoryId);
            if (!categoryExists)
            {
                ModelState.AddModelError("CategoryId", "Invalid Category selected.");
            }

            if (!ModelState.IsValid)
            {
                foreach (var error in ModelState.Values.SelectMany(v => v.Errors))
                {
                    Console.WriteLine("Validation Error: " + error.ErrorMessage);
                }
            }
            else
            {

                _context.Add(product);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }

                ViewBag.CategoryList = new SelectList(_context.Categories, "CategoryId", "CategoryName");
                return View(product);
          

            // Insert Product
            //Console.WriteLine($"Inserting Product: Name={product.ProductName}, Category={product.CategoryId}");
            //_context.Products.Add(product);
            //_context.SaveChanges();
            //Console.WriteLine("Product inserted successfully!");

            //return RedirectToAction(nameof(Index));
        }

        public IActionResult Edit(int id)
        {
            if (id == 0)
            {
                return NotFound();
            }

            var product = _context.Products.Find(id);
            if (product == null)
            {
                return NotFound();
            }

            return View(product);
        }

        // POST: Products/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(int id, [Bind("ProductId,ProductName,CategoryId")] Product product)
        {
            if (id != product.ProductId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                var existingProduct = _context.Products.Find(id);
                if (existingProduct != null)
                {
                    existingProduct.ProductName = product.ProductName;
                    existingProduct.CategoryId = product.CategoryId;

                    _context.SaveChanges();
                    return RedirectToAction(nameof(Index));
                }
            }

            return View(product);
        }
        // GET: Product/Delete/5
        public IActionResult Delete(int id)
        {
            if (id == 0)
            {
                return NotFound();
            }

            var product = _context.Products.Find(id);
            if (product == null)
            {
                return NotFound();
            }

            return View(product);
        }

        // POST: Product/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            var product = _context.Products.Find(id);
            if (product != null)
            {
                _context.Products.Remove(product);
                _context.SaveChanges();
            }

            return RedirectToAction(nameof(Index));
        }

    }
}

    

